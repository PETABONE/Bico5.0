class FeeModel:
    def __init__(self, fee_rate=0.007):
        self.fee_rate = fee_rate

    def calculate_fee(self, trade_amount):
        return trade_amount * self.fee_rate

    def apply_fee(self, trade_amount):
        return trade_amount - self.calculate_fee(trade_amount)
