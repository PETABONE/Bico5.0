from sklearn.cluster import KMeans

class BehaviorAnalysisModel:
    def __init__(self):
        self.model = KMeans(n_clusters=3)

    def train(self, trader_data):
        self.model.fit(trader_data)

    def predict(self, new_data):
        return self.model.predict(new_data)
