from textblob import TextBlob
import pandas as pd

def analyze_sentiment(text):
    analysis = TextBlob(text)
    return analysis.sentiment.polarity

def preprocess_sentiment_data(file_path):
    df = pd.read_csv(file_path)
    df['sentiment'] = df['text'].apply(analyze_sentiment)
    df.to_csv('data/sentiment_data/processed_sentiment_data.csv', index=False)

if __name__ == "__main__":
    preprocess_sentiment_data('data/sentiment_data/sentiment_data.csv')
