from sklearn.naive_bayes import MultinomialNB

class MediaAnalysisModel:
    def __init__(self):
        self.model = MultinomialNB()

    def train(self, data, labels):
        self.model.fit(data, labels)

    def predict(self, features):
        return self.model.predict(features)
