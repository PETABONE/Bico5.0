from sklearn.ensemble import RandomForestRegressor
import joblib
from utils.data_preprocessing import preprocess_data

def train_ml_model():
    df = preprocess_data('data/historical_data/market_data.csv')
    X = df[['feature1', 'feature2']]
    y = df['target']

    model = RandomForestRegressor(n_estimators=100)
    model.fit(X, y)
    joblib.dump(model, 'models/ml_model.pkl')

if __name__ == "__main__":
    train_ml_model()

