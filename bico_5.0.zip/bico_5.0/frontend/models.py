from app import db

class Trade(db.Model):
    id = db.Column(db.Integer, primary key=True)
    symbol = db.Column(db.String(10))
    volume = db.Column(db.Float)
    price = db.Column(db.Float)
    timestamp = db.Column(db.DateTime)
