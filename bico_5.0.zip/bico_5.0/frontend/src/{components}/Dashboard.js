import React from 'react';
import React from 'react';
import TradeExecution from './TradeExecution';
import Notifications from './Notifications';
import Backtesting from './';


function Dashboard() {
  return (
    <div className="Dashboard">
      <h1>Bico 5.0 Dashboard</h1>
      {/* Add dashboard components and features here */}
    </div>
  );
}

export default Dashboard;
