import React, { useState, useEffect } from 'react';
import { fetchAlerts, setNotificationPreferences } from './api';

function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [preferences, setPreferences] = useState({});

  useEffect(() => {
    fetchAlerts().then(data => setAlerts(data.alerts));
  }, []);

  const handlePreferencesChange = (event) => {
    const { name, value } = event.target;
    setPreferences(prevPreferences => ({
      ...prevPreferences,
      [name]: value
    }));
  };

  const savePreferences = () => {
    setNotificationPreferences(preferences);
  };

  return (
    <div>
      <h2>Alerts</h2>
      <div>
        {alerts.map((alert, index) => (
          <div key={index}>
            <p>{alert.message}</p>
            <p><small>{alert.timestamp}</small></p>
          </div>
        ))}
      </div>
      <h3>Notification Preferences</h3>
      <label>
        Email:
        <input type="email" name="email" onChange={handlePreferencesChange} />
      </label>
      <label>
        Notify on Significant Moves:
        <input type="checkbox" name="significant_moves" onChange={handlePreferencesChange} />
      </label>
      <button onClick={savePreferences}>Save Preferences</button>
    </div>
  );
}

export default Alerts;
