import React, { useState } from 'react';
import { fetchRiskManagementData, setRiskParameters } from './api';

function RiskManagement() {
  const [stopLoss, setStopLoss] = useState(0);
  const [takeProfit, setTakeProfit] = useState(0);
  const [recommendations, setRecommendations] = useState([]);

  const handleSetParameters = () => {
    setRiskParameters(stopLoss, takeProfit)
      .then(() => fetchRiskManagementData())
      .then(data => setRecommendations(data.recommendations));
  };

  return (
    <div>
      <h2>Risk Management</h2>
      <div>
        <label>Stop-Loss Percentage:</label>
        <input type="number" value={stopLoss} onChange={(e) => setStopLoss(e.target.value)} />
      </div>
      <div>
        <label>Take-Profit Percentage:</label>
        <input type="number" value={takeProfit} onChange={(e) => setTakeProfit(e.target.value)} />
      </div>
      <button onClick={handleSetParameters}>Set Parameters</button>
      <div>
        <h3>Diversification Recommendations:</h3>
        <ul>
          {recommendations.map((rec, index) => (
            <li key={index}>{rec.symbol}: {rec.recommendation}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default RiskManagement;
