document.getElementById('send-button').addEventListener('click', function() {
    var input = document.getElementById('chat-input').value;
    if (input.trim() !== '') {
        var messageContainer = document.createElement('div');
        messageContainer.className = 'message';
        messageContainer.textContent = 'User: ' + input;
        document.getElementById('chat-messages').appendChild(messageContainer);
        
        // Here you can integrate Bico's responses
        var bicoResponse = document.createElement('div');
        bicoResponse.className = 'message';
        bicoResponse.textContent = 'Bico: This is a placeholder response.';
        document.getElementById('chat-messages').appendChild(bicoResponse);
        
        document.getElementById('chat-input').value = '';
        document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
    }
});
