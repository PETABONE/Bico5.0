import React, { useEffect, useState } from 'react';
import { fetchDashboardData } from './api';
import Visualizations from './Visualizations';

function Dashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetchDashboardData().then(response => setData(response.data));
  }, []);

  return (
    <div className="Dashboard">
      <h2>Trading Performance</h2>
      {data ? <Visualizations data={data} /> : <p>Loading...</p>}
    </div>
  );
}

export default Dashboard;
