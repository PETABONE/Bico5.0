import React, { useState, useEffect } from 'react';
import { fetchTutorials } from './api';

function Tutorials() {
  const [tutorials, setTutorials] = useState([]);

  useEffect(() => {
    fetchTutorials().then(data => setTutorials(data.tutorials));
  }, []);

  return (
    <div>
      <h2>Tutorials and Guides</h2>
      <div>
        {tutorials.map((tutorial, index) => (
          <div key={index}>
            <h3>{tutorial.title}</h3>
            <p>{tutorial.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Tutorials;
