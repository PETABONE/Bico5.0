import React, { useState, useEffect } from 'react';
import { fetchPosts, createPost } from './api';

function Forums() {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ title: '', content: '' });

  useEffect(() => {
    fetchPosts().then(data => setPosts(data.posts));
  }, []);

  const handlePostSubmit = () => {
    createPost(newPost).then(() => {
      setPosts([...posts, newPost]);
      setNewPost({ title: '', content: '' });
    });
  };

  return (
    <div>
      <h2>Community Forums</h2>
      <div>
        <h3>Create a New Post</h3>
        <input
          type="text"
          value={newPost.title}
          onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
          placeholder="Title"
        />
        <textarea
          value={newPost.content}
          onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
          placeholder="Content"
        />
        <button onClick={handlePostSubmit}>Submit</button>
      </div>
      <div>
        <h3>Forum Posts</h3>
        {posts.map((post, index) => (
          <div key={index}>
            <h4>{post.title}</h4>
            <p>{post.content}</p>
            <small>Posted by {post.author}</small>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Forums;
