import React, { useState } from 'react';
import { loginUser, verify2FA } from './api';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1);

  const handleLogin = () => {
    loginUser(username, password)
      .then(() => setStep(2));
  };

  const handle2FAVerification = () => {
    verify2FA(otp)
      .then(() => {
        // Handle successful 2FA
      });
  };

  return (
    <div>
      {step === 1 ? (
        <div>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        <div>
          <input
            type="text"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="Enter 2FA code"
          />
          <button onClick={handle2FAVerification}>Verify</button>
        </div>
      )}
    </div>
  );
}

export default Login;
