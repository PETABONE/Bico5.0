import React, { useState } from 'react';
import { updateHistoricalModel } from './api';

function HistoricalLearning() {
  const [dataPath, setDataPath] = useState('');
  const [result, setResult] = useState(null);

  const handleUpdate = () => {
    updateHistoricalModel(dataPath).then(data => setResult(data.status));
  };

  return (
    <div>
      <h2>Historical Learning</h2>
      <input
        type="text"
        value={dataPath}
        onChange={(e) => setDataPath(e.target.value)}
        placeholder="Enter data file path"
      />
      <button onClick={handleUpdate}>Update Model</button>
      {result && <div>{result}</div>}
    </div>
  );
}

export default HistoricalLearning;
