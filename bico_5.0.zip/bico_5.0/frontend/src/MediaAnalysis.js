import React, { useState } from 'react';
import { fetchMediaAnalysis } from './api';

function MediaAnalysis() {
  const [mediaData, setMediaData] = useState('');
  const [analysisResult, setAnalysisResult] = useState(null);

  const handleAnalysis = () => {
    fetchMediaAnalysis(mediaData).then(data => setAnalysisResult(data.prediction));
  };

  return (
    <div>
      <h2>Media Analysis</h2>
      <textarea
        value={mediaData}
        onChange={(e) => setMediaData(e.target.value)}
        placeholder="Enter media data"
      />
      <button onClick={handleAnalysis}>Analyze</button>
      {analysisResult && <div>Analysis Result: {analysisResult.join(', ')}</div>}
    </div>
  );
}

export default MediaAnalysis;
