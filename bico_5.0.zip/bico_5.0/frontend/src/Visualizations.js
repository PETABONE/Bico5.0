import React from 'react';
import { Line } from 'react-chartjs-2';

function Visualizations({ data }) {
  const chartData = {
    labels: data.labels,
    datasets: [
      {
        label: 'Trading Metrics',
        data: data.values,
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
      },
    ],
  };

  return (
    <div>
      <Line data={chartData} />
    </div>
  );
}

export default Visualizations;
