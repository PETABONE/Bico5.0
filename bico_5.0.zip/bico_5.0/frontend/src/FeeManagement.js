import React, { useState } from 'react';
import { calculateFee, applyFee } from './api';

function FeeManagement() {
  const [tradeAmount, setTradeAmount] = useState('');
  const [fee, setFee] = useState(null);
  const [amountAfterFee, setAmountAfterFee] = useState(null);

  const handleCalculateFee = () => {
    calculateFee(tradeAmount).then(data => setFee(data.fee));
  };

  const handleApplyFee = () => {
    applyFee(tradeAmount).then(data => setAmountAfterFee(data.amount_after_fee));
  };

  return (
    <div>
      <h2>Fee Management</h2>
      <input
        type="number"
        value={tradeAmount}
        onChange={(e) => setTradeAmount(e.target.value)}
        placeholder="Enter trade amount"
      />
      <button onClick={handleCalculateFee}>Calculate Fee</button>
      <button onClick={handleApplyFee}>Apply Fee</button>
      {fee !== null && <div>Calculated Fee: {fee}</div>}
      {amountAfterFee !== null && <div>Amount After Fee: {amountAfterFee}</div>}
    </div>
  );
}

export default FeeManagement;
