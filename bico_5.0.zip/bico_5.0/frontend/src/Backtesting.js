import React, { useState } from 'react';
import { runBacktest, fetchPerformanceMetrics } from './api';

function Backtesting() {
  const [strategyCode, setStrategyCode] = useState('');
  const [performance, setPerformance] = useState(null);

  const handleRunBacktest = () => {
    runBacktest(strategyCode)
      .then(() => fetchPerformanceMetrics())
      .then(data => setPerformance(data.metrics));
  };

  return (
    <div>
      <h2>Backtesting</h2>
      <textarea
        value={strategyCode}
        onChange={(e) => setStrategyCode(e.target.value)}
        placeholder="Enter your trading strategy code here"
      />
      <button onClick={handleRunBacktest}>Run Backtest</button>
      {performance && (
        <div>
          <h3>Performance Insights</h3>
          <p>Total Return: {performance.total_return}%</p>
        </div>
      )}
    </div>
  );
}

export default Backtesting;
