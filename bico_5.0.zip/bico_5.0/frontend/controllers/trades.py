from flask import request, jsonify
from app import app, db
from models import Trade

@app.route('/trades', methods=['GET', 'POST'])
def trades():
    if request.method == 'POST':
        data = request.get_json()
        trade = Trade(
            symbol=data['symbol'],
            volume=data['volume'],
            price=data['price'],
            timestamp=data['timestamp']
        )
        db.session.add(trade)
        db.session.commit()
        return jsonify({'message': 'Trade added'}), 201
    trades = Trade.query.all()
    return jsonify([trade.serialize() for trade in trades])
