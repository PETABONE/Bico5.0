from app import db

class Trade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(10))
    volume = db.Column(db.Float)
    price = db.Column(db.Float)
    timestamp = db.Column(db.DateTime)

    def serialize(self):
        return {
            'id': self.id,
            'symbol': self.symbol,
            'volume': self.volume,
            'price': self.price,
            'timestamp': self.timestamp.isoformat()
        }
