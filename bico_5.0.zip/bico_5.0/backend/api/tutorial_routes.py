from flask import Blueprint, jsonify

tutorial_routes = Blueprint('tutorial_routes', __name__)

@tutorial_routes.route('/tutorials', methods=['GET'])
def get_tutorials():
    tutorials = [
        {'title': 'Getting Started with Trading', 'content': 'Content of the tutorial...'},
        {'title': 'How to Use Bico 5.0', 'content': 'Content of the guide...'}
    ]
    return jsonify({'tutorials': tutorials})

