from flask import Blueprint, request, jsonify
from models.psychological_model import PsychologicalModel
from utils.psychological_utils import extract_psychological_features

psychological_routes = Blueprint('psychological_routes', __name__)
model = PsychologicalModel()

@psychological_routes.route('/psychological_analysis', methods=['POST'])
def psychological_analysis():
    trader_data = request.json['trader_data']
    features = extract_psychological_features(trader_data)
    prediction = model.predict(features)
    return jsonify({'prediction': prediction.tolist()})
