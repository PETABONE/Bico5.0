from flask import Blueprint, request, jsonify
from notification_utils import customize_notifications

notification_routes = Blueprint('notification_routes', __name__)

@notification_routes.route('/alerts', methods=['GET'])
def get_alerts():
    # Example alerts data
    alerts = [
        {'message': 'Significant market movement detected.', 'timestamp': '2024-08-01T12:00:00Z'}
    ]
    return jsonify({'alerts': alerts})

@notification_routes.route('/set_preferences', methods=['POST'])
def set_preferences():
    data = request.json
    # Save user preferences (e.g., to a database)
    # Example preferences: {'email': 'user@example.com', 'significant_moves': True}
    return jsonify({'status': 'Preferences updated successfully'})
