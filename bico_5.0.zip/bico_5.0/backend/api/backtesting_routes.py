from flask import Blueprint, request, jsonify
import subprocess
import json
import pandas as pd

backtesting_routes = Blueprint('backtesting_routes', __name__)

@backtesting_routes.route('/run_backtest', methods=['POST'])
def run_backtest():
    data = request.json
    strategy_code = data['strategy_code']
    # Save strategy code and execute backtest
    with open('scripts/strategy_code.py', 'w') as file:
        file.write(strategy_code)
    subprocess.run(['python3', 'scripts/backtesting.py'])
    return jsonify({'status': 'Backtest completed successfully'})

@backtesting_routes.route('/performance', methods=['GET'])
def get_performance_metrics():
    # Load performance metrics from a file or database
    results = pd.read_csv('data/processed_data/performance_metrics.csv')
    metrics = results.to_dict(orient='records')
    return jsonify({'metrics': metrics})
