from flask import Blueprint, jsonify
import pandas as pd

dashboard_data = Blueprint('dashboard_data', __name__)

@dashboard_data.route('/dashboard', methods=['GET'])
def get_dashboard_data():
    # Load and return dashboard data from a CSV or database
    data = pd.read_csv('data/processed_data/dashboard_data.csv')
    response = {
        'labels': data['date'].tolist(),
        'values': data['value'].tolist()
    }
    return jsonify(response)
