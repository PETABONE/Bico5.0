from flask import Blueprint, request, jsonify

forum_routes = Blueprint('forum_routes', __name__)

@forum_routes.route('/posts', methods=['GET'])
def get_posts():
    posts = [
        {'id': 1, 'title': 'Trading Strategies', 'content': 'Content of the post...', 'author': 'User1'},
        {'id': 2, 'title': 'Market Analysis Tips', 'content': 'Content of the post...', 'author': 'User2'}
    ]
    return jsonify({'posts': posts})

@forum_routes.route('/posts/<int:post_id>/comments', methods=['GET'])
def get_comments(post_id):
    comments = [
        {'id': 1, 'content': 'Great post!', 'author': 'User3'},
        {'id': 2, 'content': 'Thanks for sharing!', 'author': 'User4'}
    ]
    return jsonify({'comments': comments})

@forum_routes.route('/posts', methods=['POST'])
def create_post():
    data = request.json
    # Save the new post
    return jsonify({'status': 'Post created successfully'})
