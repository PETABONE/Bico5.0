from flask import Blueprint, request, jsonify
from models.historical_learning_model import HistoricalLearningModel
from utils.historical_utils import preprocess_historical_data

historical_routes = Blueprint('historical_routes', __name__)
model = HistoricalLearningModel()

@historical_routes.route('/update_historical_model', methods=['POST'])
def update_model():
    data_path = request.json['data_path']
    update_historical_model(data_path)
    return jsonify({'status': 'Model updated successfully'})
