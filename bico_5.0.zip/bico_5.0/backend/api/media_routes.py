from flask import Blueprint, request, jsonify
from models.media_analysis_model import MediaAnalysisModel
from utils.media_utils import process_media_data

media_routes = Blueprint('media_routes', __name__)
model = MediaAnalysisModel()

@media_routes.route('/media_analysis', methods=['POST'])
def media_analysis():
    raw_media_data = request.json['media_data']
    processed_data = process_media_data(raw_media_data)
    prediction = model.predict(processed_data)
    return jsonify({'prediction': prediction.tolist()})
