from flask import Flask
from .tutorial_routes import tutorial_routes
from .forum_routes import forum_routes

app = Flask(__name__)
app.register_blueprint(tutorial_routes, url_prefix='/api/tutorials')
app.register_blueprint(forum_routes, url_prefix='/api/forums')
