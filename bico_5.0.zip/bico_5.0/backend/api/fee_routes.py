from flask import Blueprint, request, jsonify
from models.fee_model import FeeModel

fee_routes = Blueprint('fee_routes', __name__)
fee_model = FeeModel()

@fee_routes.route('/calculate_fee', methods=['POST'])
def calculate_fee():
    trade_amount = request.json['trade_amount']
    fee = fee_model.calculate_fee(trade_amount)
    return jsonify({'fee': fee})

@fee_routes.route('/apply_fee', methods=['POST'])
def apply_fee():
    trade_amount = request.json['trade_amount']
    amount_after_fee = fee_model.apply_fee(trade_amount)
    return jsonify({'amount_after_fee': amount_after_fee})
