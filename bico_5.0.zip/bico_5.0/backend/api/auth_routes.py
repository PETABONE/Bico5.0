from flask import Blueprint, request, jsonify
import pyotp
import secrets

auth_routes = Blueprint('auth_routes', __name__)

@auth_routes.route('/generate_2fa', methods=['POST'])
def generate_2fa_secret():
    user_id = request.json['user_id']
    secret = pyotp.random_base32()
    # Save the secret to the user's profile
    return jsonify({'secret': secret})

@auth_routes.route('/verify_2fa', methods=['POST'])
def verify_2fa():
    user_id = request.json['user_id']
    code = request.json['code']
    secret = # Retrieve the secret from user's profile
    totp = pyotp.TOTP(secret)
    if totp.verify(code):
        return jsonify({'status': '2FA verified'})
    return jsonify({'status': 'Invalid code'}), 401
