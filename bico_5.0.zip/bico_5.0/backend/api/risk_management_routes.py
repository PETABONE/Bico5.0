from flask import Blueprint, request, jsonify
from risk_management_utils import recommend_diversification

risk_management_routes = Blueprint('risk_management_routes', __name__)

@risk_management_routes.route('/set_parameters', methods=['POST'])
def set_parameters():
    data = request.json
    stop_loss = data['stop_loss']
    take_profit = data['take_profit']
    # Save these parameters or apply them to trading strategies
    return jsonify({'status': 'Parameters set successfully'})



@risk_management_routes.route('/recommendations', methods=['GET'])
def get_recommendations():
    # Example portfolio data
    portfolio = [
        {'symbol': 'AAPL', 'value': 10000},
        {'symbol': 'GOOGL', 'value': 20000}
    ]
    recommendations = recommend_diversification(portfolio, max_allocation=50)
    return jsonify({'recommendations': recommendations})
