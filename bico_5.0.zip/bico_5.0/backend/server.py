from flask import Flask,request, jsonify
from api.routes import dashboard_data
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash
from flask_sqlalchemy import SQLAlchemy
from api.routes import main

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)

CORS(app)

@app.before_request
def authenticate():
    token = request.headers.get('Authorization')
    if not token or not validate_token(token):
        return jsonify({'error': 'Unauthorized'}), 401

def validate_token(token):
    # Implement token validation logic here
    return True

# Define your API routes here


app.register_blueprint(dashboard_data, url_prefix='/api')

if __name__ == "__main__":
    app.run(debug=True)

