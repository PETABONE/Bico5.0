from models.fee_model import FeeModel

def process_trade(trade_amount):
    fee_model = FeeModel()
    amount_after_fee = fee_model.apply_fee(trade_amount)
    # Implement trade execution with the fee applied
    return amount_after_fee
