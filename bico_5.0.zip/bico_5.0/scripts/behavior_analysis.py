from models.behavior_analysis_model import BehaviorAnalysisModel
from utils.behavior_utils import analyze_trader_behavior

def analyze_behavior(trader_data_path):
    data = pd.read_csv(trader_data_path)
    analyzed_data = analyze_trader_behavior(data)
    
    model = BehaviorAnalysisModel()
    model.train(analyzed_data)
    # Save model for future use
