import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email_alert(subject, message, to_email):
    from_email = "your_email@example.com"
    password = "your_password"

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(message, 'plain'))

    with smtplib.SMTP('smtp.example.com', 587) as server:
        server.starttls()
        server.login(from_email, password)
        server.sendmail(from_email, to_email, msg.as_string())

def check_market_conditions():
    # Placeholder function to check market conditions
    # Implement your logic to detect significant movements
    return True  # Assume a condition was met for demonstration

if __name__ == "__main__":
    if check_market_conditions():
        send_email_alert(
            subject="Market Alert",
            message="Significant market movement detected.",
            to_email="user@example.com"
        )
