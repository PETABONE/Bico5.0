import requests

def fetch_media_data(api_endpoint):
    response = requests.get(api_endpoint)
    media_data = response.json()
    return media_data
