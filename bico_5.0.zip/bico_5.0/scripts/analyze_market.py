import pandas as pd
from models.ml_model import MLModel
from models.sentiment_model import SentimentModel
from models.psychological_model import PsychologicalModel
from models.media_analysis_model import MediaAnalysisModel
from utils.data_preprocessing import preprocess_data
from utils.sentiment_analysis import analyze_sentiment
from utils.psychological_utils import analyze_psychology
from utils.media_utils import analyze_media

def analyze_market(data):
    # Preprocess the data
    processed_data = preprocess_data(data)
    
    # Machine Learning Predictions
    ml_predictions = MLModel().predict(processed_data)
    
    # Sentiment Analysis
    sentiment_scores = SentimentModel().predict(analyze_sentiment(data))
    
    # Psychological Analysis
    psychological_scores = PsychologicalModel().predict(analyze_psychology(data))
    
    # Media Analysis
    media_scores = MediaAnalysisModel().predict(analyze_media(data))
    
    # Combine the results
    analysis_results = {
        "ml_predictions": ml_predictions,
        "sentiment_scores": sentiment_scores,
        "psychological_scores": psychological_scores,
        "media_scores": media_scores
    }
    
    return analysis_results

if __name__ == "__main__":
    # Example usage
    market_data = pd.read_csv("path_to_market_data.csv")
    results = analyze_market(market_data)
    print(results)
