import time
from process_real_time_data import process_and_update_models

def periodic_update(interval=3600):
    while True:
        process_and_update_models()
        time.sleep(interval)  # Update models every `interval` seconds

if __name__ == "__main__":
    periodic_update()
