class BaseStrategy:
    def __init__(self, data):
        self.data = data

    def apply_strategy(self):
        raise NotImplementedError("Please implement the strategy.")

class MovingAverageStrategy(BaseStrategy):
    def apply_strategy(self):
        # Example of a simple moving average strategy
        self.data["SMA_50"] = self.data["Close"].rolling(window=50).mean()
        self.data["SMA_200"] = self.data["Close"].rolling(window=200).mean()
        
        self.data["Signal"] = 0
        self.data["Signal"][50:] = [1 if self.data["SMA_50"].iloc[i] > self.data["SMA_200"].iloc[i] else 0 for i in range(50, len(self.data))]
        self.data["Position"] = self.data["Signal"].diff()
        
        return self.data

class RSIStrategy(BaseStrategy):
    def apply_strategy(self):
        # Example of an RSI strategy
        delta = self.data["Close"].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        
        RS = gain / loss
        RSI = 100 - (100 / (1 + RS))
        
        self.data["RSI"] = RSI
        
        self.data["Signal"] = 0
        self.data["Signal"][14:] = [1 if self.data["RSI"].iloc[i] < 30 else 0 if self.data["RSI"].iloc[i] > 70 else None for i in range(14, len(self.data))]
        self.data["Position"] = self.data["Signal"].diff()
        
        return self.data

if __name__ == "__main__":
    import pandas as pd
    # Example usage
    market_data = pd.read_csv("path_to_market_data.csv")
    strategy = MovingAverageStrategy(market_data)
    result = strategy.apply_strategy()
    print(result)
