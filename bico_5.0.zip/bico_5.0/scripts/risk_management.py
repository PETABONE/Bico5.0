import pandas as pd

def apply_stop_loss_take_profit(trades, stop_loss_percentage, take_profit_percentage):
    # trades is a DataFrame with columns: ['symbol', 'entry_price', 'quantity']
    trades['stop_loss_price'] = trades['entry_price'] * (1 - stop_loss_percentage / 100)
    trades['take_profit_price'] = trades['entry_price'] * (1 + take_profit_percentage / 100)
    return trades

if __name__ == "__main__":
    trades = pd.DataFrame({
        'symbol': ['AAPL', 'GOOGL'],
        'entry_price': [150.00, 2500.00],
        'quantity': [10, 5]
    })
    updated_trades = apply_stop_loss_take_profit(trades, stop_loss_percentage=2, take_profit_percentage=5)
    print(updated_trades)
