import pandas as pd
from utils.data_preprocessing import preprocess_data
from models.ml_model import train_ml_model
from models.sentiment_model import train_sentiment_model

def process_and_update_models():
    # Process the real-time data
    df = pd.read_csv('data/real_time_data/latest_data.csv')
    processed_df = preprocess_data(df)

    # Update models with new data
    # You may want to append this new data to a training set or use it to retrain models
    train_ml_model()  # Optionally retrain ML model with new data
    train_sentiment_model()  # Optionally retrain sentiment model

if __name__ == "__main__":
    process_and_update_models()
