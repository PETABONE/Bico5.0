import pandas as pd
from datetime import datetime

def backtest_strategy(strategy, historical_data):
    results = []
    for index, row in historical_data.iterrows():
        signal = strategy(row)
        results.append({
            'date': row['date'],
            'signal': signal,
            'price': row['price']
        })
    return pd.DataFrame(results)

def sample_strategy(row):
    # Example strategy: Buy if price is lower than 100, sell if higher
    if row['price'] < 100:
        return 'buy'
    elif row['price'] > 100:
        return 'sell'
    return 'hold'

if __name__ == "__main__":
    historical_data = pd.read_csv('data/historical_data/example_data.csv')
    results = backtest_strategy(sample_strategy, historical_data)
    print(results)
