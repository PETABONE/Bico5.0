import requests
import pandas as pd

def fetch_historical_data():
    # Example URL - replace with actual data source
    url = "https://api.example.com/historical_data"
    response = requests.get(url)
    data = response.json()
    df = pd.DataFrame(data)
    df.to_csv('data/historical_data/market_data.csv', index=False)

def fetch_sentiment_data():
    # Example URL - replace with actual data source
    url = "https://api.example.com/sentiment_data"
    response = requests.get(url)
    data = response.json()
    df = pd.DataFrame(data)
    df.to_csv('data/sentiment_data/sentiment_data.csv', index=False)

if __name__ == "__main__":
    fetch_historical_data()
    fetch_sentiment_data()

