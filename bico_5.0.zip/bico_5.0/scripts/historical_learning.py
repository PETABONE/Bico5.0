from models.historical_learning_model import HistoricalLearningModel
from utils.historical_utils import load_historical_data, preprocess_historical_data

def update_historical_model(data_path):
    data = load_historical_data(data_path)
    processed_data = preprocess_historical_data(data)
    features = processed_data.drop('target', axis=1)
    targets = processed_data['target']
    
    model = HistoricalLearningModel()
    model.train(features, targets)
    # Save model for future use
