import requests
import pandas as pd
import time

def fetch_real_time_data():
    # Example URL - replace with actual data source
    url = "https://api.example.com/realtime_data"
    response = requests.get(url)
    data = response.json()
    df = pd.DataFrame(data)
    df.to_csv('data/real_time_data/latest_data.csv', index=False)

def continuous_fetch(interval=60):
    while True:
        fetch_real_time_data()
        time.sleep(interval)  # Fetch data every `interval` seconds

if __name__ == "__main__":
    continuous_fetch()
