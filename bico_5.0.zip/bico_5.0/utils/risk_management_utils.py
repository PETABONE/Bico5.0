def calculate_risk(exposure, stop_loss_percentage):
    return exposure * stop_loss_percentage / 100

def recommend_diversification(portfolio, max_allocation):
    total_value = sum(stock['value'] for stock in portfolio)
    recommendations = []
    for stock in portfolio:
        allocation_percentage = (stock['value'] / total_value) * 100
        if allocation_percentage > max_allocation:
            recommendations.append({
                'symbol': stock['symbol'],
                'recommendation': 'Reduce allocation'
            })
        else:
            recommendations.append({
                'symbol': stock['symbol'],
                'recommendation': 'Okay'
            })
    return recommendations
