def calculate_performance_metrics(results):
    # Example: Calculate total return and risk metrics
    initial_capital = 10000
    final_capital = initial_capital
    for result in results:
        if result['signal'] == 'buy':
            final_capital *= (1 + (result['price'] / 100))  # Simplified example
        elif result['signal'] == 'sell':
            final_capital *= (1 - (result['price'] / 100))
    return {
        'total_return': (final_capital - initial_capital) / initial_capital * 100
    }
