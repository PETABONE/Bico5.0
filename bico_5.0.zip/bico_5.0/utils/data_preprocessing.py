import pandas as pd
from sklearn.preprocessing import StandardScaler

def preprocess_data(file_path):
    df = pd.read_csv(file_path)
    # Example preprocessing steps
    df.fillna(method='ffill', inplace=True)
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df[['feature1', 'feature2']])
    df[['feature1', 'feature2']] = scaled_features
    return df
