def get_trade_amount_with_fee(trade_amount, fee_rate=0.007):
    fee = trade_amount * fee_rate
    return trade_amount - fee
