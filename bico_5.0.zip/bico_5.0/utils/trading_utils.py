def get_trade_details(signal, data):
    # Implement logic to generate trade details based on signal
    trade_details = {
        'symbol': data['symbol'].iloc[0],
        'quantity': 10,  # Example quantity
        'price': data['price'].iloc[0]
    }
    return trade_details

