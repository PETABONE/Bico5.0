import os
import hashlib
import hmac
import base64
import random
import string
from typing import Tuple
import pyotp

class AuthenticationUtils:
    def __init__(self):
        self.secret = os.getenv("AUTH_SECRET", "default_secret_key")

    def hash_password(self, password: str) -> str:
        salt = os.urandom(16)
        pwdhash = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
        return base64.b64encode(salt + pwdhash).decode("utf-8")

    def verify_password(self, stored_password: str, provided_password: str) -> bool:
        stored_password = base64.b64decode(stored_password.encode("utf-8"))
        salt = stored_password[:16]
        stored_pwdhash = stored_password[16:]
        pwdhash = hashlib.pbkdf2_hmac("sha256", provided_password.encode("utf-8"), salt, 100000)
        return hmac.compare_digest(stored_pwdhash, pwdhash)

    def generate_totp_secret(self) -> str:
        return pyotp.random_base32()

    def generate_totp_token(self, secret: str) -> str:
        totp = pyotp.TOTP(secret)
        return totp.now()

    def verify_totp_token(self, secret: str, token: str) -> bool:
        totp = pyotp.TOTP(secret)
        return totp.verify(token)

    def generate_random_string(self, length: int = 12) -> str:
        letters_and_digits = string.ascii_letters + string.digits
        return ''.join(random.choice(letters_and_digits) for i in range(length))

if __name__ == "__main__":
    auth_utils = AuthenticationUtils()
    
    # Example usage
    password = "my_secure_password"
    hashed_password = auth_utils.hash_password(password)
    print(f"Hashed Password: {hashed_password}")
    
    is_valid = auth_utils.verify_password(hashed_password, password)
    print(f"Password is valid: {is_valid}")
    
    totp_secret = auth_utils.generate_totp_secret()
    print(f"TOTP Secret: {totp_secret}")
    
    totp_token = auth_utils.generate_totp_token(totp_secret)
    print(f"TOTP Token: {totp_token}")
    
    is_token_valid = auth_utils.verify_totp_token(totp_secret, totp_token)
    print(f"TOTP Token is valid: {is_token_valid}")
