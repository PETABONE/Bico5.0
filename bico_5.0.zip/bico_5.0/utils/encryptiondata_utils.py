def anonymize_data(data):
    return hash(data)  # Simplified example
